package com.shop.localzone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LocalZoneApplicationTests {

	@Test
	void contextLoads() {
	}

}
