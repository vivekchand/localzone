package com.shop.localzone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LocalZoneApplication {

	public static void main(String[] args) {
		SpringApplication.run(LocalZoneApplication.class, args);
	}

}
